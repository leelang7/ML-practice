import os
import sys

sys.path.append(os.getcwd())

from grader_elice_utils import EliceUtils  # isort:skip # noqa: F402

elice_utils = EliceUtils()

def grade():
    import main as sub
    import sol_main as sol_sub
    import preprocess as pre
    import model as md
    
    total_score = 0

    X = pre.load_data()
    
    loss = sub.silhouette_calculator(X, sub.your_choice(X).cluster )
    sol_loss = sol_sub.silhouette_calculator(X, sub.your_choice(X).cluster )
    
    ##### Case 1: 
    if abs(loss - sol_loss) < 0.001:
        elice_utils.secure_send_grader('Testcase 1: 정답 (%d points)\n' % (50))
        total_score+=50
    else:
        elice_utils.secure_send_grader('Testcase 1: 오답 \n')
        elice_utils.secure_send_grader('silhouette calculator 함수를 다시 완성해보세요.\n')
    
    ##### Case 2: 
    
    if loss >= 0.46:
        elice_utils.secure_send_grader('Testcase 2: 정답 (%d points)\n' % (50))
        total_score+=50
    else:
        elice_utils.secure_send_grader('Testcase 2: 오답 \n')
        elice_utils.secure_send_grader('모델의 파라미터 값을 다시 설정해보세요.\n')
        
    
    elice_utils.secure_send_grader('\n총점: %d points\n' % (total_score))
    # SEND SCORE TO ELICE
    elice_utils.secure_send_score(total_score)

try:
    elice_utils.secure_init()
    grade()
except Exception:
    elice_utils.secure_send_grader('채점 중 오류가 발생하였습니다. 실행 버튼을 눌러 코드 실행에 오류가 없는지 확인해주세요.')
    elice_utils.secure_send_score(0)
    sys.exit(1)