import numpy as np

# 두 포인트 사이의 유클리드 거리 계산식을 구현합니다.
def dist(x1, x2):
    return np.sqrt(np.sum((x1 - x2)**2))

# distances ( N by K) shape의 ndarray 와 cluster_labels 리스트를 인수로 하고, inertia를 계산하는 inertia 함수를 완성합니다.  
def inertia(distances, cluster_labels):
    Inertia = 0
    # 각 데이터에 할당된 군집리스트 (cluster_labels)를 기준으로  
    # 데이터포인트와 각 군집 중심과의 거리 (distances)에서 취사선택하여 합계를 구합니다.
    for i,label in enumerate(cluster_labels):
        Inertia +=  distances[i, label]
    return Inertia

class KMeans:
    # 군집의 갯수, random_state, 최대 iteration 수 를 모수로 받아들입니다.
    # 군집의 중심을 저장하기위한 dictionary, inertia, 등을 초기화 합니다.
       
    def __init__(self, K, max_iter =  100, random_state = 6):
        self.n_cluster = K
        self.max_iter = max_iter
        # 군집의 중심을 저장하기 위한 dictionary. 각 군집의 id에 해당하는 `key`에, (1,2) shape를 가지는 빈 array를 `value`로 초기화
        self.centroid = {}
        for i in range(K):
            self.centroid[i] = np.empty(shape = (1,2))
        # 매 iteration의 inertia의 값을 저장할 empty list로 초기화
        self.Inertia = []
        self.random_state = random_state
    
    
    def fit(self, feature_data):
        
        x = feature_data
        
        ## Step 1: 군집 중심을 초기화합니다.
        # centroid는 빈 dictionary로 초기화 하여 임의의 
        centroid = {}
        # 무작위 추출을 수행하기 전에 random_state로 random seed를 설정 합니다.
        np.random.seed(self.random_state)
        # 전체 샘플 중에서 군집의 개수 만큼 임의의 샘플의 id를 뽑습니다.
        sampled_idx = np.random.randint(x.shape[0], size = self.n_cluster)
        # 무작위로 추출한 샘플에 대해서, (key: 각 군집의 id, value: 해당 id의 샘플의 벡터값) 으로 저장합니다.
        # 현 객체의 attribute centroid로 저장합니다.
        for i, idx in enumerate(sampled_idx):
            self.centroid[i] = x[idx, :]
        
        # 최대 `max_iter` 동안만 반복하도록 for 루프를 사용합니다.        
        for _ in range(self.max_iter):
            # Step 2 각 데이터 포인트로 부터, 군집의 중심까지의 유클리드 거리를 계산. 
            cluster = {}
            # Inertia = []
            distances = []

            for i in range(x.shape[0]):
            # 각 군집중심과의 거리를 측정하고, list d에 저장합니다.
                d = []
                for c in self.centroid.values():
                    d.append( dist(x[i,:], c ))
                    
                # 데이터 포인트 i을, i번째 샘플과 가장 거리가 가까운 군집 중심의 군집으로 할당
                cluster[i] = d.index(min(d))
                # 각 샘플에서 각 군집중심과의 거리를 담고 있는 d를 list distances에 저장합니다.
                distances.append( np.array( [d]) )
            
            # Step 3 업데이트되어 할당된 군집을 기반으로 각 군집의 중심을 업데이트
            # 새로운 centroid를 만들어 초기화합니다. 
            centroid = {}
            for i in range(self.n_cluster):
                centroid[i] = np.empty(shape = (1,2))
                
                # 각 군집 별로, 각 군집에 해당하는 샘플을 sample_pool 리스트에 logical 타입으로 저장합니다.
                samples_in_cl = [cl_id == i for cl_id in cluster.values()]
                sample_pool = x[samples_in_cl, :]
                # 각 군집 별로, sample_pool의 사이즈가 1 이상 일때, sample_pool의 샘플들의 평균으로 centroid를 업데이트 합니다.
                # 각 군집 별로, sample_pool의 사이즈가 1 미만 일때, 업데이트 하지 않고, 이전 centroid 를 유지합니다.
                if ( len( sample_pool) > 0 ):
                    centroid[i] = np.mean(sample_pool, 0)
                else:
                    centroid[i] = self.centroid[i]
                    
            # Step 4 Step2,3를 반복. 군집중심의 좌표에 변동이 없으면 중단합니다. 변동이 있는경우, 현 객체의 attribute: centroid와 cluster를 업데이트 된 centroid와 cluster로 변경합니다.
            # 업데이트 전의 centroid와 업데이트 후의 centroid를 비교합니다.
            # dictionary의 value(np.array)들만 모아 리스트를 만든 후, concatenate 함수를 사용하여 1열로 나열하여 한번에 비교할 수 있습니다.
            if ( ( np.concatenate(list( self.centroid.values())) == np.concatenate(list( centroid.values())) ).all()):
                break
            else:
                self.centroid = centroid 
                self.cluster = cluster
                # inertia 함수를 사용하여 distances 와 cluter label 값으로 부터 inertia의 값을 구합니다.
                self.Inertia.append( inertia(np.concatenate(distances), list(cluster.values())) )
        return self