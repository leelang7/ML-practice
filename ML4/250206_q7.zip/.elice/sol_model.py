import numpy as np
from scipy.linalg import svd

class PCA:
       
    def __init__(self, n_components ):
        # 생성자 실행시 속성(attribute)의 초기화를 위한 코드를 설정합니다.
        self.n_components = n_components # 군집의 개수
        self.lambda_ = np.array([]) #학습시, 고유값을 저장합니다.
        self.V =  np.array([])# 학습시, 고유 벡터를 저장합니다.
        self.mean_ = np.array([]) # 학습시, 데이터 포인트의 평균을 저장합니다.
        self.W = np.array([]) # 학습시, 변환 행렬을 저장합니다.
    
    def fit_transform(self, X):
        
        # 데이터 셋의 평균을 구하여 저장합니다.
        self.mean_ = X.mean(axis = 0)
        
        # 데이터 셋의 분산 행렬을 계산합니다.
        diff = X - self.mean_
        cov = diff.T.dot(diff)
        
        # 분산 행렬을 고유값 분해를 사용하여, 고유값과 고유벡터를 추출합니다.
        self.V, self.lambda_, _ = svd(cov)
        
        # 추출된 고유값에대해 큰 순서대로 n_component개를 골라서 변환행렬로 저장합니다.
        order = (-self.lambda_).argsort()
        self.W = self.V[:,order[0:self.n_components]]
        
        # 변환행렬로 주어진 feature_data를 선형변환하여, 저차원의 벡터로 변환합니다.
        return (X - self.mean_).dot(self.W)

    def inverse_transform(self, X_hat):
        # 저차원 벡터로 변환된 벡터를 인수로 받습니다.
        
        # 학습된 변환행렬의 역변환행렬로 저차원의 벡터를 고차원의 벡터로 변환합니다.
        # 이전에 저장해두었던 데이터셋의 평균을 더하여 기존 차원의 벡터로 복구된 주성분 벡터를 반환합니다.
        return (X_hat).dot(self.W.T) + self.mean_
    
    
    