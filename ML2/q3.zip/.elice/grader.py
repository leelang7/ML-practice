import os
import sys

sys.path.append(os.getcwd())

from grader_elice_utils import EliceUtils  # isort:skip # noqa: F402

elice_utils = EliceUtils()



def grade():
    import sol_preprocess as sol_pre
    import preprocess as pre

    total_score = 0
    testcase_index = 0
    scores = [50, 50]

    
    independent_var=['petal length', 'sepal length']
    
    x_train, y_train, x_val, y_val = pre.load_data('./data/iris.csv', independent_var=['petal length', 'sepal length'], response_var='class_num')
    
    sol_x_train, sol_y_train, sol_x_val, sol_y_val = sol_pre.load_data('./data/iris.csv', independent_var=['petal length', 'sepal length'], response_var='class_num')


    ## Case4 : 올바른 모델 학습 (kernel = linear) ##########################################

    import svm as sv
    import sol_svm as sol_sv

    clf_svm = sv.train_model(x_train, y_train)
    sol_clf_svm = sol_sv.train_model(sol_x_train, sol_y_train)

    if ((clf_svm.kernel == sol_clf_svm.kernel ) and
            (clf_svm.kernel == 'linear')):
        if ((sol_clf_svm.C == clf_svm.C) and (clf_svm.C == 80)):
            if (hasattr(clf_svm, 'coef_') and (sol_clf_svm.coef_ == clf_svm.coef_).all() and
                    (sol_clf_svm.intercept_ == clf_svm.intercept_)):
                total_score += scores[testcase_index]
                elice_utils.secure_send_grader('Testcase %d: 정답 (%d points)\n' %
                                               (testcase_index + 1, scores[testcase_index]))
            else:
                elice_utils.secure_send_grader('Testcase %d: 오답\n' % (testcase_index + 1))
                elice_utils.secure_send_grader('모델이 올바르게 구성되지 않았습니다.\n')
        else:
            elice_utils.secure_send_grader('Testcase %d: 오답\n' % (testcase_index + 1))
            elice_utils.secure_send_grader('모델이 올바르게 구성되지 않았습니다. (C 값이 다릅니다.)\n')
    else:
        elice_utils.secure_send_grader('Testcase %d: 오답\n' % (testcase_index + 1))
        elice_utils.secure_send_grader('모델이 올바르게 구성되지 않았습니다. (커널 타입이 다릅니다.)\n')

    testcase_index += 1

    ## Case5 : 올바른 성능 출력 ##########################################
    mean_acc = sv.evaluate_model(clf_svm, x_val, y_val)
    sol_mean_acc = sol_sv.evaluate_model(sol_clf_svm, sol_x_val, sol_y_val)

    if (mean_acc == sol_mean_acc):
        total_score += scores[testcase_index]
        elice_utils.secure_send_grader('Testcase %d: 정답 (%d points)\n' %
                                       (testcase_index + 1, scores[testcase_index]))
    else:
        elice_utils.secure_send_grader('Testcase %d: 오답\n' % (testcase_index + 1))
        elice_utils.secure_send_grader('모델 성능 측정 함수가 올바르게 구성되지 않았습니다.\n')

    testcase_index += 1

    ## SEND SCORE TO ELICE ###################################################

    elice_utils.secure_send_grader('\n총점: %d points\n' % (total_score))

    elice_utils.secure_send_score(total_score)


try:
    elice_utils.secure_init()
    grade()
except Exception:
    elice_utils.secure_send_grader('채점 중 오류가 발생하였습니다. 실행 버튼을 눌러 코드 실행에 오류가 없는지 확인해주세요.')
    elice_utils.secure_send_score(0)
    sys.exit(1)