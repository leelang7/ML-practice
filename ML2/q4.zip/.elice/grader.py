import os
import sys

sys.path.append(os.getcwd())

from grader_elice_utils import EliceUtils  # isort:skip # noqa: F402

elice_utils = EliceUtils()

def grade():
    import sol_preprocess as sol_pre
    import preprocess as pre

    total_score = 0
    testcase_index = 0
    scores = [20,20,20,20,20]

    independent_var = ['petal length', 'sepal length']
    
    x_train, y_train, x_val, y_val = pre.load_data('./data/iris.csv', independent_var = ['petal length', 'sepal length'], response_var='class_num')

    sol_x_train, sol_y_train, sol_x_val, sol_y_val = sol_pre.load_data('./data/iris.csv', independent_var = ['petal length', 'sepal length'], response_var='class_num')
    
    ## Case1 : 모델1 ##########################################

    import svm as sv
    import sol_svm as sol_sv
    
    linear_svm = sv.train_linear_model(x_train, y_train)
    sol_linear_svm = sol_sv.train_linear_model(sol_x_train, sol_y_train)
    
    if ( ( linear_svm.kernel == sol_linear_svm.kernel) and ( linear_svm.kernel =='linear') ):
        if ( (sol_linear_svm.C == linear_svm.C) and (linear_svm.C == 10) ):
            if ( hasattr(linear_svm, 'coef_') and (sol_linear_svm.support_ == linear_svm.support_).all() and
                    ( sol_linear_svm.dual_coef_ == linear_svm.dual_coef_).all() ):
                total_score += scores[testcase_index]
                elice_utils.secure_send_grader('Testcase %d: 정답 (%d points)\n' %
                                               (testcase_index + 1, scores[testcase_index]))
            else:
                elice_utils.secure_send_grader('Testcase %d: 오답\n' % (testcase_index + 1))
                elice_utils.secure_send_grader('첫 번째 모델이 올바르게 구성되지 않았습니다.\n')
        else:
            elice_utils.secure_send_grader('Testcase %d: 오답\n' % (testcase_index + 1))
            elice_utils.secure_send_grader('첫 번째 모델이 올바르게 구성되지 않았습니다. (C 값이 다릅니다.)\n')
    else:
        elice_utils.secure_send_grader('Testcase %d: 오답\n' % (testcase_index + 1))
        elice_utils.secure_send_grader('첫 번째 모델이 올바르게 구성되지 않았습니다. (커널 타입이 다릅니다.)\n')

    testcase_index += 1
    
    ## Case2 : 모델2 ##########################################
    
    poly_svm = sv.train_linear_model(x_train, y_train)
    sol_poly_svm = sol_sv.train_linear_model(sol_x_train, sol_y_train)
    
    if ( ( poly_svm.kernel == sol_poly_svm.kernel) and ( poly_svm.kernel =='linear') ):
        if ( (sol_poly_svm.C == poly_svm.C) and (poly_svm.C == 10) ):
            if ( hasattr(poly_svm, 'coef_') and (sol_poly_svm.support_ == poly_svm.support_).all() and
                    ( sol_poly_svm.dual_coef_ == poly_svm.dual_coef_).all() ):
                total_score += scores[testcase_index]
                elice_utils.secure_send_grader('Testcase %d: 정답 (%d points)\n' %
                                               (testcase_index + 1, scores[testcase_index]))
            else:
                elice_utils.secure_send_grader('Testcase %d: 오답\n' % (testcase_index + 1))
                elice_utils.secure_send_grader('두 번째 모델이 올바르게 구성되지 않았습니다.\n')
        else:
            elice_utils.secure_send_grader('Testcase %d: 오답\n' % (testcase_index + 1))
            elice_utils.secure_send_grader('두 번째 모델이 올바르게 구성되지 않았습니다. (C 값이 다릅니다.)\n')
    else:
        elice_utils.secure_send_grader('Testcase %d: 오답\n' % (testcase_index + 1))
        elice_utils.secure_send_grader('두 번째 모델이 올바르게 구성되지 않았습니다. (커널 타입이 다릅니다.)\n')
        
    ## Case3 : 모델3 ##########################################
    
    rbf_svm = sv.train_linear_model(x_train, y_train)
    sol_rbf_svm = sol_sv.train_linear_model(sol_x_train, sol_y_train)
    
    if ( ( rbf_svm.kernel == sol_rbf_svm.kernel) and ( rbf_svm.kernel =='linear') ):
        if ( (sol_rbf_svm.C == rbf_svm.C) and (rbf_svm.C == 10) ):
            if ( hasattr(rbf_svm, 'coef_') and (sol_rbf_svm.support_ == rbf_svm.support_).all() and
                    ( sol_rbf_svm.dual_coef_ == rbf_svm.dual_coef_).all() ):
                total_score += scores[testcase_index]
                elice_utils.secure_send_grader('Testcase %d: 정답 (%d points)\n' %
                                               (testcase_index + 1, scores[testcase_index]))
            else:
                elice_utils.secure_send_grader('Testcase %d: 오답\n' % (testcase_index + 1))
                elice_utils.secure_send_grader('세 번째 모델이 올바르게 구성되지 않았습니다.\n')
        else:
            elice_utils.secure_send_grader('Testcase %d: 오답\n' % (testcase_index + 1))
            elice_utils.secure_send_grader('세 번째 모델이 올바르게 구성되지 않았습니다. (C 값이 다릅니다.)\n')
    else:
        elice_utils.secure_send_grader('Testcase %d: 오답\n' % (testcase_index + 1))
        elice_utils.secure_send_grader('세 번째 모델이 올바르게 구성되지 않았습니다. (커널 타입이 다릅니다.)\n')
        
    
    ## Case4 : 모델4 ##########################################
    
    sig_svm = sv.train_linear_model(x_train, y_train)
    sol_sig_svm = sol_sv.train_linear_model(sol_x_train, sol_y_train)
    
    if ( ( sig_svm.kernel == sol_sig_svm.kernel) and ( sig_svm.kernel =='linear') ):
        if ( (sol_sig_svm.C == sig_svm.C) and (sig_svm.C == 10) ):
            if ( hasattr(sig_svm, 'coef_') and (sol_sig_svm.support_ == sig_svm.support_).all() and
                    ( sol_sig_svm.dual_coef_ == sig_svm.dual_coef_).all() ):
                total_score += scores[testcase_index]
                elice_utils.secure_send_grader('Testcase %d: 정답 (%d points)\n' %
                                               (testcase_index + 1, scores[testcase_index]))
            else:
                elice_utils.secure_send_grader('Testcase %d: 오답\n' % (testcase_index + 1))
                elice_utils.secure_send_grader('네 번째 모델이 올바르게 구성되지 않았습니다.\n')
        else:
            elice_utils.secure_send_grader('Testcase %d: 오답\n' % (testcase_index + 1))
            elice_utils.secure_send_grader('네 번째 모델이 올바르게 구성되지 않았습니다. (C 값이 다릅니다.)\n')
    else:
        elice_utils.secure_send_grader('Testcase %d: 오답\n' % (testcase_index + 1))
        elice_utils.secure_send_grader('네 번째 모델이 올바르게 구성되지 않았습니다. (커널 타입이 다릅니다.)\n')



    ## Case3 : 올바른 성능 출력 ##########################################
    mean_acc = sv.evaluate_model(linear_svm, x_val, y_val)
    sol_mean_acc = sol_sv.evaluate_model(sol_linear_svm, sol_x_val, sol_y_val)

    if (mean_acc == sol_mean_acc):
        total_score += scores[testcase_index]
        elice_utils.secure_send_grader('Testcase %d: 정답 (%d points)\n' %
                                       (testcase_index + 1, scores[testcase_index]))
        elice_utils.secure_send_grader('모델의 성능이 올바르게 출력되었습니다.\n')
    else:
        elice_utils.secure_send_grader('Testcase %d: 오답\n' % (testcase_index + 1))
        elice_utils.secure_send_grader('모델 성능 측정 함수가 올바르게 구성되지 않았습니다.\n')

    ## SEND SCORE TO ELICE ###################################################

    elice_utils.secure_send_grader('\n총점: %d points\n' % (total_score))

    elice_utils.secure_send_score(total_score)

try:
    elice_utils.secure_init()
    grade()
except Exception:
    elice_utils.secure_send_grader('채점 중 오류가 발생하였습니다. 실행 버튼을 눌러 코드 실행에 오류가 없는지 확인해주세요.')
    elice_utils.secure_send_score(0)
    sys.exit(1)