python3 -u main.py
